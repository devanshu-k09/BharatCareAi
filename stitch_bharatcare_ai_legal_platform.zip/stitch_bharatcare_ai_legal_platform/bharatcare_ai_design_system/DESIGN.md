---
name: BharatCare AI Design System
colors:
  surface: '#f7f9fb'
  surface-dim: '#d8dadc'
  surface-bright: '#f7f9fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f6'
  surface-container: '#eceef0'
  surface-container-high: '#e6e8ea'
  surface-container-highest: '#e0e3e5'
  on-surface: '#191c1e'
  on-surface-variant: '#444651'
  inverse-surface: '#2d3133'
  inverse-on-surface: '#eff1f3'
  outline: '#757682'
  outline-variant: '#c5c5d3'
  surface-tint: '#4059aa'
  primary: '#00236f'
  on-primary: '#ffffff'
  primary-container: '#1e3a8a'
  on-primary-container: '#90a8ff'
  inverse-primary: '#b6c4ff'
  secondary: '#0051d5'
  on-secondary: '#ffffff'
  secondary-container: '#316bf3'
  on-secondary-container: '#fefcff'
  tertiary: '#4b1c00'
  on-tertiary: '#ffffff'
  tertiary-container: '#6e2c00'
  on-tertiary-container: '#f39461'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dce1ff'
  primary-fixed-dim: '#b6c4ff'
  on-primary-fixed: '#00164e'
  on-primary-fixed-variant: '#264191'
  secondary-fixed: '#dbe1ff'
  secondary-fixed-dim: '#b4c5ff'
  on-secondary-fixed: '#00174b'
  on-secondary-fixed-variant: '#003ea8'
  tertiary-fixed: '#ffdbcb'
  tertiary-fixed-dim: '#ffb691'
  on-tertiary-fixed: '#341100'
  on-tertiary-fixed-variant: '#773205'
  background: '#f7f9fb'
  on-background: '#191c1e'
  surface-variant: '#e0e3e5'
typography:
  display-lg:
    fontFamily: Manrope
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Manrope
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Manrope
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
  headline-md:
    fontFamily: Manrope
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 14px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 32px
  2xl: 48px
  3xl: 64px
  container-max: 1280px
  gutter: 24px
---

## Brand & Style

The design system is engineered for a premium legal SaaS environment, prioritizing trust, authority, and high-efficiency intelligence. The aesthetic is a fusion of **Modern Minimalism** and **Corporate Precision**, drawing inspiration from the structured utility of Linear and the approachable clarity of Notion.

The UI is designed to feel calm and systematic, reducing the cognitive load often associated with complex legal jargon. It utilizes generous whitespace, a strict "content-first" hierarchy, and subtle functional transitions. The emotional response is one of reliability and technological sophistication—reassuring the user that their legal matters are being handled by a precise, state-of-the-art AI.

## Colors

The palette is anchored in professional deep blues to evoke the traditional authority of legal institutions, while being energized by bright cyan accents to signal AI-driven innovation.

- **Primary & Secondary:** Used for core branding, primary actions, and navigational anchors.
- **Backgrounds:** A clean, off-white surface (`#F8FAFC`) is used for the main application canvas to reduce glare, while pure white is reserved for cards and modular containers to create distinct layering.
- **Functional Colors:** Success, Warning, and Danger colors follow standard semantic patterns but are slightly desaturated to maintain the premium, professional tone.
- **Borders:** Low-contrast borders (`#E5E7EB`) define structure without cluttering the visual field.

## Typography

This design system employs a dual-font strategy to balance character with utility. 

- **Manrope** is used for headings and display text. Its geometric yet warm proportions feel modern and trustworthy, perfect for legal titles and AI insights.
- **Inter** is the workhorse for all body copy, inputs, and UI labels. It provides exceptional legibility at small sizes, crucial for reading lengthy legal documents and chat logs.

Strict typographic hierarchy is maintained through weight variance (Medium for labels, Bold for headers) and controlled line heights to ensure a rhythmic reading experience.

## Layout & Spacing

The design system follows a strictly proportional 8px grid system. 

- **Grid:** A 12-column fluid grid is used for desktop layouts, transitioning to a single-column stack on mobile.
- **Margins:** Large page margins (32px+) on desktop give the content "room to breathe," reflecting a high-end SaaS experience.
- **Density:** The system prioritizes "Comfortable" density for document reading and "Compact" density for data tables and legal citations.
- **Chat Interface:** For the AI assistance component, a centered, fixed-width column (max 800px) is utilized to mimic a natural reading flow and focus the user's attention.

## Elevation & Depth

Visual hierarchy is achieved through a combination of **Tonal Layering** and **Ambient Shadows**. 

1.  **Level 0 (Surface):** The background (`#F8FAFC`).
2.  **Level 1 (Cards/Panels):** Pure white surfaces with a very soft, multi-layered shadow (0px 1px 3px rgba(0,0,0,0.05), 0px 10px 15px rgba(0,0,0,0.03)). 
3.  **Level 2 (Dropdowns/Modals):** Pure white with a more pronounced elevation shadow to indicate temporary interaction and focus.

Borders are used sparingly to define boundaries on Level 1 elements, while Level 2 elements rely more on shadow depth to sit above the page.

## Shapes

The design system utilizes a **Rounded** shape language to soften the serious nature of legal work and make the technology feel more accessible.

- **Standard Elements:** Buttons, input fields, and small cards use a 0.5rem (8px) radius.
- **Containers:** Large layout sections and main content cards use a 1rem (16px) radius for a modern, "app-like" feel.
- **Avatars/Status:** Use full pill-shaped or circular radii to distinguish them from structural UI elements.

## Components

### Buttons
Primary buttons use the `#1E3A8A` primary blue with white text. Secondary buttons use a subtle gray outline or ghost style. Interaction states (hover/active) should involve a slight darkening of the background color and a subtle lift in shadow.

### Input Fields
Inputs are white with a 1px border (`#E5E7EB`). On focus, the border transitions to Primary Blue with a soft 3px blue outer glow. Labels always sit above the input in `label-md` style.

### AI Chat Bubbles
AI-generated responses sit on a very subtle light blue tint (`#F0F9FF`) to distinguish them from user messages, which are anchored to the right and use the Primary color or a clean white card.

### Chips & Badges
Used for legal categories (e.g., "Family Law," "Property Tax"). These use `label-sm` typography with high-contrast backgrounds (light tint of the category color with dark text) and a 0.5rem radius.

### Cards
All cards feature a 1px border and the Level 1 soft shadow. Content within cards follows a 24px internal padding (Spacing LG) to maintain the premium feel.

### Lists
Legal document lists or search results use "Clean Row" styling: minimal borders between items, high-contrast primary text for titles, and secondary text for metadata (dates/file size).